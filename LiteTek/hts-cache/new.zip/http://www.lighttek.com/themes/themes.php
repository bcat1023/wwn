 <html>
<head>
<meta http-equiv="Description" content="Desktop manager and shell replacement software for Windows 95/98/ME/NT4/2000/XP/Vista/7. Customized interface builder program for office, home, touchscreen computers">
<meta http-equiv="Keywords" content="desktop, workspace, graphic viewer, 3D, interface, clock, taskbar, calendar, shape, setup, builder, net, download, internet, customize, change, network, LAN, intranet, fast, cool, sexy, anime, wallpaper, best, flexible, internet, unlimited, customization, changer, shell, Windows, picture, image, reliable, home computer, kiosk, hotel, game club, games, gamer, school, university, pc, shareware, free">
<title>Lighttek Software. Programs for desktop management, shell replacement. 32bit icons, themes, skins, visual styles for Windows</title>
<meta name="language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link rel="stylesheet" type="text/css" href="../lt.css">
</head>

<body bgcolor="#013F01" text="#000000" vlink="#0000FF" alink="#000080">
 <center>
  <table border="0" width="851" cellspacing="0" cellpadding="0" bgcolor="#F5FFF2">
    <tr>
      <td width="140" valign="top" background="../images/4-bar2.gif"><map name="FPMap0">
        <area href="../index.htm" shape="rect" coords="15, 28, 140, 224">
        <area href="themes.php?D1=0&amp;D5=Date" shape="rect" coords="33, 229, 139, 246">
        <area href="themes.php?D1=Icon%20Sets&amp;D5=Date" shape="rect" coords="32, 245, 141, 261">
        <area href="themes.php?D1=Clock%20Objects&amp;D5=Date" shape="rect" coords="32, 262, 140, 279">
        <area href="themes.php?D1=Calendar%20Objects&amp;D5=Date" coords="33, 278, 139, 298" shape="rect">
        <area href="themes.php?D1=Shape%20Objects&amp;D5=Date" coords="34, 298, 139, 314" shape="rect">
        <area href="themes.php?D1=Plugins&amp;D5=Date" shape="rect" coords="34, 314, 140, 331">
        <area href="themes.php?D1=Menus&amp;D5=Date" shape="rect" coords="34, 331, 140, 351">
        <area href="../themes2/wallpapers/index.htm" shape="rect" coords="34, 353, 141, 381">
        <area href="themes.php?D1=Alteros3D%20Skins&amp;D5=Date" shape="rect" coords="33, 381, 139, 408">
        <area href="addtheme.htm" shape="rect" coords="33, 410, 139, 435">
        <area href="orders.htm" coords="32, 435, 143, 467" shape="rect"></map><img border="0" src="../images/bartheme.jpg" align="top" usemap="#FPMap0" width="147" height="508">
        <div align="right">
    <table border="0" width="130">
      <tr>
        <td width="100%">&nbsp;&nbsp;&nbsp;&nbsp; <a href="../cd.htm"><img border="0" src="../lcd.jpg" width="100" height="95"></a></td>
      </tr>
      <tr>
        <td width="100%">
          <p align="center"><b><font face="Arial" color="#99FF99" size="1">&nbsp;&nbsp;&nbsp;&nbsp;
          </font><a href="../cd.htm"><font face="Arial" color="#99FF99" size="1">Lighttek CDROM<br>
          </font></a><font face="Arial" color="#99FF99" size="1"><a href="../cd.htm">&nbsp;&nbsp;
          </a></font></b><font face="Arial" color="#99FF99" size="1">400 best
          themes<br>
          for Talisman&nbsp;&nbsp;&nbsp;</font></p>
      </td>
      </tr>
    </table>
        </div>
        <p>&nbsp;</p>
        <p>&nbsp;</td>
      <td width="100%" valign="top" background="../images/4theme-center.gif">



  </center>

      <img border="0" src="../images/4theme-top-1.jpg" width="704" height="87">
      <div align="center">
        <center>
      <table border="1" cellpadding="0" width="90%" cellspacing="4" bordercolor="#FFFFFF" bordercolorlight="#FFFFFF" bordercolordark="#FFFFFF">
        <tr>
          <td width="100%" bordercolor="#808080" bordercolorlight="#808080" bordercolordark="#808080" class="texth" bgcolor="#FFFFCC">
            <p style="margin-left: 8; margin-right: 8"><font color="#000000" size="1"><b>&nbsp;<br>
            </b></font><b><font face="Arial" color="#000000" size="2">How to install a
            Talisman theme?:</font></b><font face="Arial" color="#000000" size="2">&nbsp;</font><font color="#000000" size="1"><font face="Arial">
            1)
            Start Talisman Desktop.&nbsp; 2) Drag and drop the downloaded ZIP
            file in any (free) place of Talisman Desktop. Installation procedure
            will be started automatically. </font><br>
            &nbsp;</font></td>
        </tr>
      </table>

        </center>
      </div>



 <table width="90%" align="center" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF" bgcolor="#FFFFFF">
  <tr valign='top'>
     <td valign="top" align="left" colspan="2" class="text">
     <FORM name=theForm method="POST" action="themes.php" >

         <p align='center' class='text'>Category:
          <SELECT name=D1 size=1>
<option  value=0 >All Themes</option><option >--------------------</option><option >Anime</option><option >Avia</option><option >Beauties</option><option >Cars</option><option >Desktop Panels</option><option >Games</option><option >German</option><option >HTPC</option><option >Movies</option><option >OS Emulation</option><option >Sport</option><option >--------------------</option><option >Icon Sets</option><option >Menus</option><option >Plugins</option><option >Clock Objects</option><option >Calendar Objects</option><option >Shape Objects</option><option >--------------------</option><option >Alteros3D Skins</option>           </SELECT>
&nbsp; Author:
          <SELECT name=D2 size=1>
<option  value=0 >All Authors</option><option >--------------------</option><option >Aist</option><option >Bob Starck-Higgins</option><option >Chinmayo</option><option >DEI</option><option >Gymenii</option><option >Kevx</option><option >Pahan</option><option >Roger Dufleit</option><option >Uktus</option>           </SELECT>
&nbsp;&nbsp;<br>
&nbsp;<br>
          Resolution:
          <SELECT name=D3 size=1>
<option  value=0 >All Resolutions</option><option >--------------------</option><option >640x480</option><option >800x600</option><option >1024x768</option><option >1152x864</option><option >1280x1024</option><option >1600x1280</option><option >1920x1200</option><option >Dual Monitors</option><option >1024x768 and higher</option><option >800x600 and higher</option>           </SELECT>
          Show:
          <SELECT name=D4 size=1>
<option  value=10 selected >10 items </option><option  value=20>20 items </option><option  value=40>40 items </option>           </SELECT>
          Sort by:&nbsp;
          <SELECT name=D5 size=1>
<option  selected >Date</option><option >Downloads</option><option >Rating</option>          </SELECT>
        </p>
         <p align='center' class='text'>&nbsp;
          <INPUT name='Submit' type=submit style='font-size: 8pt; font-family: Arial' value='Go!'>
        </p>
       </form>
       </td>
   </tr>

 <tr>
   <td colspan=2 align=center valign=top class=text> <hr color=#B1F3AF size=1>
     <p align=right> &nbsp;All themes : Pages 1&nbsp;<a href=themes.php?PGN=2&D1=0&D2=0&D3=0&D4=10&D5=Date>2</a>&nbsp;<a href=themes.php?PGN=3&D1=0&D2=0&D3=0&D4=10&D5=Date>3</a>&nbsp;<a href=themes.php?PGN=4&D1=0&D2=0&D3=0&D4=10&D5=Date>4</a>&nbsp;<a href=themes.php?PGN=5&D1=0&D2=0&D3=0&D4=10&D5=Date>5</a>&nbsp; (75)&nbsp; <b><a href=themes.php?PGN=2&D1=0&D2=0&D3=0&D4=10&D5=Date>&gt;&gt;</a></b></p><br></td>
 </tr>

  <tr valign='top'>
     <td valign=top align=center width=234> <font face=Arial><img src="../thumbnails/storm200.jpg" vspace=2 border=0 hspace=2 alt="Full View"></font>
      <p align='center' class='text'>Download sites:</p>
      <p align='center' class='text'><a href="dl.php?id=951&u=1" target=_blank><img border="0" src="images/download1.gif" alt="Download site 1" width="24" height="24"></a> <a href="dl.php?id=951&u=2" target=_blank><img border="0" src="images/download2.gif" alt="Download site 2" width="24" height="24"></a> </p></td>
     <td valign='top'> <p style='margin-left: 8; margin-right: 8' class='Header'>Storm </p>
      <p style='margin-left: 8; margin-right: 8' class='text'><b>Rating:</b>&nbsp; <img border="0" src=images/star.gif width=14 height=15><img border="0" src=images/star.gif width=14 height=15><img border="0" src=images/star.gif width=14 height=15><img border="0" src=images/star.gif width=14 height=15>  &nbsp;&nbsp;&nbsp;&nbsp;</p>
      <p style='margin-left: 8; margin-right: 8' class='text'><b>Resolution:</b>&nbsp; Any<br>
         <b>Filesize:</b> 710 kb<br>
         <b>Author: </b>Bob Starck-Higgins &nbsp;&nbsp;  &nbsp; <br>
         <b>Downloads:</b> 8465</p>
      <p style='margin-left: 8; margin-right: 8' class='text'> <b>Description: </b> A simple uncluttered full screen theme with a comprehensive menu for ease of use.</p></td>
   </tr>
   <tr valign='top'>
     <td valign=top><br><br>
     </td>
   </tr>
  <tr valign='top'>
     <td valign=top align=center width=234> <font face=Arial><img src="../thumbnails/sliders200.jpg" vspace=2 border=0 hspace=2 alt="Full View"></font>
      <p align='center' class='text'>Download sites:</p>
      <p align='center' class='text'><a href="dl.php?id=949&u=1" target=_blank><img border="0" src="images/download1.gif" alt="Download site 1" width="24" height="24"></a>  </p></td>
     <td valign='top'> <p style='margin-left: 8; margin-right: 8' class='Header'>Sliders </p>
      <p style='margin-left: 8; margin-right: 8' class='text'><b>Rating:</b>&nbsp; Not defined  &nbsp;&nbsp;&nbsp;&nbsp;</p>
      <p style='margin-left: 8; margin-right: 8' class='text'><b>Resolution:</b>&nbsp; 1024x768 and higher<br>
         <b>Filesize:</b> 800 kb<br>
         <b>Author: </b>Aist &nbsp;&nbsp;  &nbsp; <br>
         <b>Downloads:</b> 8406</p>
      <p style='margin-left: 8; margin-right: 8' class='text'> <b>Description: </b> Theme for Talisman Desktop 3.3 and higher versions.
<br />
Screen resolution: 1024x768 and higher.</p></td>
   </tr>
   <tr valign='top'>
     <td valign=top><br><br>
     </td>
   </tr>
  <tr valign='top'>
     <td valign=top align=center width=234> <font face=Arial><img src="../thumbnails/8screens200.jpg" vspace=2 border=0 hspace=2 alt="Full View"></font>
      <p align='center' class='text'>Download sites:</p>
      <p align='center' class='text'><a href="dl.php?id=946&u=1" target=_blank><img border="0" src="images/download1.gif" alt="Download site 1" width="24" height="24"></a> <a href="dl.php?id=946&u=2" target=_blank><img border="0" src="images/download2.gif" alt="Download site 2" width="24" height="24"></a> </p></td>
     <td valign='top'> <p style='margin-left: 8; margin-right: 8' class='Header'>8 screens </p>
      <p style='margin-left: 8; margin-right: 8' class='text'><b>Rating:</b>&nbsp; Not defined  &nbsp;&nbsp;&nbsp;&nbsp;</p>
      <p style='margin-left: 8; margin-right: 8' class='text'><b>Resolution:</b>&nbsp; Any<br>
         <b>Filesize:</b> 84 kb<br>
         <b>Author: </b>Lighttek Software &nbsp;&nbsp;  &nbsp; <a target='_blank' href='http://www.lighttek.com'>Homepage</a><br>
         <b>Downloads:</b> 8448</p>
      <p style='margin-left: 8; margin-right: 8' class='text'> <b>Description: </b> Example of a simple theme for corporate or kiosk interfaces.
<br />
Main screen with links to 8 additional screens for your applications.
<br />
Administrator button in the top-right corner of the main screen.
<br />
Administrator can add or edit any button on all screens.
<br />
User can not change anything in protected mode.
<br />
(This theme included in Talisman 3.3 installation)</p></td>
   </tr>
   <tr valign='top'>
     <td valign=top><br><br>
     </td>
   </tr>
  <tr valign='top'>
     <td valign=top align=center width=234> <font face=Arial><img src="../thumbnails/winter2011200.jpg" vspace=2 border=0 hspace=2 alt="Full View"></font>
      <p align='center' class='text'>Download sites:</p>
      <p align='center' class='text'><a href="dl.php?id=938&u=1" target=_blank><img border="0" src="images/download1.gif" alt="Download site 1" width="24" height="24"></a> <a href="dl.php?id=938&u=2" target=_blank><img border="0" src="images/download2.gif" alt="Download site 2" width="24" height="24"></a> </p></td>
     <td valign='top'> <p style='margin-left: 8; margin-right: 8' class='Header'>Winter 2011 </p>
      <p style='margin-left: 8; margin-right: 8' class='text'><b>Rating:</b>&nbsp; Not defined  &nbsp;&nbsp;&nbsp;&nbsp;</p>
      <p style='margin-left: 8; margin-right: 8' class='text'><b>Resolution:</b>&nbsp; 1024x768 and higher<br>
         <b>Filesize:</b> 510 kb<br>
         <b>Author: </b>Aist &nbsp;&nbsp;  &nbsp; <a target='_blank' href='http://www.lighttek.com'>Homepage</a><br>
         <b>Downloads:</b> 8446</p>
      <p style='margin-left: 8; margin-right: 8' class='text'> <b>Description: </b> For Talisman 3.21 and higher versions.
<br />
Any screen resolutions (1024x768 and higher).
<br />

<br />
Merry Christmas and Happy New Year!
<br />

<br />
</p></td>
   </tr>
   <tr valign='top'>
     <td valign=top><br><br>
     </td>
   </tr>
  <tr valign='top'>
     <td valign=top align=center width=234> <font face=Arial><img src="../thumbnails/dual2200.jpg" vspace=2 border=0 hspace=2 alt="Full View"></font>
      <p align='center' class='text'>Download sites:</p>
      <p align='center' class='text'><a href="dl.php?id=937&u=1" target=_blank><img border="0" src="images/download1.gif" alt="Download site 1" width="24" height="24"></a>  </p></td>
     <td valign='top'> <p style='margin-left: 8; margin-right: 8' class='Header'>Dual v2.0 </p>
      <p style='margin-left: 8; margin-right: 8' class='text'><b>Rating:</b>&nbsp; <img border="0" src=images/star.gif width=14 height=15><img border="0" src=images/star.gif width=14 height=15><img border="0" src=images/star.gif width=14 height=15><img border="0" src=images/star.gif width=14 height=15><img border="0" src=images/star.gif width=14 height=15>  &nbsp;&nbsp;&nbsp;&nbsp;</p>
      <p style='margin-left: 8; margin-right: 8' class='text'><b>Resolution:</b>&nbsp; Any<br>
         <b>Filesize:</b> 4000 kb<br>
         <b>Author: </b>DEI &nbsp;&nbsp; <a href='mailto:evdu@mail.ru'>E-mail</a> &nbsp; <a target='_blank' href='http://www.customize.org/DEI/gallery'>Homepage</a><br>
         <b>Downloads:</b> 8406</p>
      <p style='margin-left: 8; margin-right: 8' class='text'> <b>Description: </b> 2 in 1
<br />
Full  Screen  Theme and Desktop Panel
<br />
System Requirements:
<br />
Talisman Desktop 3.2 and higher
<br />
Screen resolution: 1280*  and higher
<br />

<br />
Icons: 130 pieces from them 69 pieces in the size of 256 pixels for appendices.
<br />
All graphic files only for private, not for commercial use.
<br />
All rights reserved.
<br />
                                                 12.2010  DEI</p></td>
   </tr>
   <tr valign='top'>
     <td valign=top><br><br>
     </td>
   </tr>
  <tr valign='top'>
     <td valign=top align=center width=234> <font face=Arial><img src="../thumbnails/faenza200.jpg" vspace=2 border=0 hspace=2 alt="Full View"></font>
      <p align='center' class='text'>Download sites:</p>
      <p align='center' class='text'><a href="dl.php?id=936&u=1" target=_blank><img border="0" src="images/download1.gif" alt="Download site 1" width="24" height="24"></a>  </p></td>
     <td valign='top'> <p style='margin-left: 8; margin-right: 8' class='Header'>Faenza </p>
      <p style='margin-left: 8; margin-right: 8' class='text'><b>Rating:</b>&nbsp; <img border="0" src=images/star.gif width=14 height=15><img border="0" src=images/star.gif width=14 height=15><img border="0" src=images/star.gif width=14 height=15><img border="0" src=images/star.gif width=14 height=15><img border="0" src=images/star.gif width=14 height=15>  &nbsp;&nbsp;&nbsp;&nbsp;</p>
      <p style='margin-left: 8; margin-right: 8' class='text'><b>Resolution:</b>&nbsp; 1024x768 and higher<br>
         <b>Filesize:</b> 936 kb<br>
         <b>Author: </b>Pahan &nbsp;&nbsp;  &nbsp; <a target='_blank' href='http://pahan2.deviantart.com'>Homepage</a><br>
         <b>Downloads:</b> 8403</p>
      <p style='margin-left: 8; margin-right: 8' class='text'> <b>Description: </b> 1024x768+
<br />
Talisman 3.21+
<br />

<br />
Icons: Faenza by Tiheum (http://tiheum.deviantart.com)
<br />

<br />
Wallpaper: KDE (sorry - I can not find the author name!)</p></td>
   </tr>
   <tr valign='top'>
     <td valign=top><br><br>
     </td>
   </tr>
  <tr valign='top'>
     <td valign=top align=center width=234> <font face=Arial><img src="../thumbnails/greenwhite200.jpg" vspace=2 border=0 hspace=2 alt="Full View"></font>
      <p align='center' class='text'>Download sites:</p>
      <p align='center' class='text'><a href="dl.php?id=935&u=1" target=_blank><img border="0" src="images/download1.gif" alt="Download site 1" width="24" height="24"></a> <a href="dl.php?id=935&u=2" target=_blank><img border="0" src="images/download2.gif" alt="Download site 2" width="24" height="24"></a> </p></td>
     <td valign='top'> <p style='margin-left: 8; margin-right: 8' class='Header'>Roksana </p>
      <p style='margin-left: 8; margin-right: 8' class='text'><b>Rating:</b>&nbsp; <img border="0" src=images/star.gif width=14 height=15><img border="0" src=images/star.gif width=14 height=15><img border="0" src=images/star.gif width=14 height=15><img border="0" src=images/star.gif width=14 height=15>  &nbsp;&nbsp;&nbsp;&nbsp;</p>
      <p style='margin-left: 8; margin-right: 8' class='text'><b>Resolution:</b>&nbsp; 1024x768 and higher<br>
         <b>Filesize:</b> 450 kb<br>
         <b>Author: </b>Pahan &nbsp;&nbsp;  &nbsp; <a target='_blank' href='http://pahan2.deviantart.com'>Homepage</a><br>
         <b>Downloads:</b> 8452</p>
      <p style='margin-left: 8; margin-right: 8' class='text'> <b>Description: </b> 1024x768+
<br />
Talisman Desktop 3.21+</p></td>
   </tr>
   <tr valign='top'>
     <td valign=top><br><br>
     </td>
   </tr>
  <tr valign='top'>
     <td valign=top align=center width=234> <font face=Arial><img src="../thumbnails/wooddesk200.jpg" vspace=2 border=0 hspace=2 alt="Full View"></font>
      <p align='center' class='text'>Download sites:</p>
      <p align='center' class='text'><a href="dl.php?id=934&u=1" target=_blank><img border="0" src="images/download1.gif" alt="Download site 1" width="24" height="24"></a> <a href="dl.php?id=934&u=2" target=_blank><img border="0" src="images/download2.gif" alt="Download site 2" width="24" height="24"></a> </p></td>
     <td valign='top'> <p style='margin-left: 8; margin-right: 8' class='Header'>WoodDesk </p>
      <p style='margin-left: 8; margin-right: 8' class='text'><b>Rating:</b>&nbsp; Not defined  &nbsp;&nbsp;&nbsp;&nbsp;</p>
      <p style='margin-left: 8; margin-right: 8' class='text'><b>Resolution:</b>&nbsp; 1024x768 and higher<br>
         <b>Filesize:</b> 340 kb<br>
         <b>Author: </b>Aist &nbsp;&nbsp;  &nbsp; <br>
         <b>Downloads:</b> 8442</p>
      <p style='margin-left: 8; margin-right: 8' class='text'> <b>Description: </b> Simple theme for Talisman 3.21 and higher versions.
<br />
For Application mode of Talisman only (this theme has not own taskbar/tray/clock).
<br />
For any screen resolutions (1024x768 and higher).
<br />
Used 2 icons by Everaldo Coelho (http://everaldo.com/crystal).</p></td>
   </tr>
   <tr valign='top'>
     <td valign=top><br><br>
     </td>
   </tr>
  <tr valign='top'>
     <td valign=top align=center width=234> <font face=Arial><img src="../thumbnails/dual200.jpg" vspace=2 border=0 hspace=2 alt="Full View"></font>
      <p align='center' class='text'>Download sites:</p>
      <p align='center' class='text'><a href="dl.php?id=933&u=1" target=_blank><img border="0" src="images/download1.gif" alt="Download site 1" width="24" height="24"></a>  </p></td>
     <td valign='top'> <p style='margin-left: 8; margin-right: 8' class='Header'>Dual </p>
      <p style='margin-left: 8; margin-right: 8' class='text'><b>Rating:</b>&nbsp; <img border="0" src=images/star.gif width=14 height=15><img border="0" src=images/star.gif width=14 height=15><img border="0" src=images/star.gif width=14 height=15><img border="0" src=images/star.gif width=14 height=15>  &nbsp;&nbsp;&nbsp;&nbsp;</p>
      <p style='margin-left: 8; margin-right: 8' class='text'><b>Resolution:</b>&nbsp; Any<br>
         <b>Filesize:</b> 4700 kb<br>
         <b>Author: </b>DEI &nbsp;&nbsp; <a href='mailto:evdu@mail.ru'>E-mail</a> &nbsp; <br>
         <b>Downloads:</b> 8409</p>
      <p style='margin-left: 8; margin-right: 8' class='text'> <b>Description: </b> 2 in 1
<br />
Full Screen Theme and Desktop Panel
<br />
System Requirements:
<br />
Talisman Desktop 3.2 and higher
<br />
Screen resolution: 1280* and higher
<br />
</p></td>
   </tr>
   <tr valign='top'>
     <td valign=top><br><br>
     </td>
   </tr>
  <tr valign='top'>
     <td valign=top align=center width=234> <font face=Arial><a href="http://th03.deviantart.net/fs71/300W/i/2010/048/5/9/Windows_8_concept___Talisman___by_somrat.jpg" target="_blank"><img src="../thumbnails/w8200.jpg" vspace=2 border=0 hspace=2 alt="Full View"></a></font>
      <p align='center' class='text'>Download sites:</p>
      <p align='center' class='text'><a href="dl.php?id=932&u=1" target=_blank><img border="0" src="images/download1.gif" alt="Download site 1" width="24" height="24"></a>  </p></td>
     <td valign='top'> <p style='margin-left: 8; margin-right: 8' class='Header'>Windows 8 concept (UPDATE for Talisman 3.2) </p>
      <p style='margin-left: 8; margin-right: 8' class='text'><b>Rating:</b>&nbsp; <img border="0" src=images/star.gif width=14 height=15><img border="0" src=images/star.gif width=14 height=15><img border="0" src=images/star.gif width=14 height=15>  &nbsp;&nbsp;&nbsp;&nbsp;</p>
      <p style='margin-left: 8; margin-right: 8' class='text'><b>Resolution:</b>&nbsp; Any<br>
         <b>Filesize:</b> 4200 kb<br>
         <b>Author: </b>Shivadeep Baruah &nbsp;&nbsp; <a href='mailto:shivadip.barua@gmail.com'>E-mail</a> &nbsp; <a target='_blank' href='http://somrat.deviantart.com'>Homepage</a><br>
         <b>Downloads:</b> 8396</p>
      <p style='margin-left: 8; margin-right: 8' class='text'> <b>Description: </b> Note: Updated for Talisman 3.2. Fixed bugs.
<br />

<br />
Its my conceptual design for Windows 8. Best works with resolution 1280x800 or above. Theme offers.. New start button, split taskbar, startmenu, windows task window, clock and calendar..
<br />
</p></td>
   </tr>
   <tr valign='top'>
     <td valign=top><br><br>
     </td>
   </tr>
 <tr>
   <td colspan=2 align=center valign=top class=text> <hr color=#B1F3AF size=1>
     <p align=right> &nbsp;All themes : Pages 1&nbsp;<a href=themes.php?PGN=2&D1=0&D2=0&D3=0&D4=10&D5=Date>2</a>&nbsp;<a href=themes.php?PGN=3&D1=0&D2=0&D3=0&D4=10&D5=Date>3</a>&nbsp;<a href=themes.php?PGN=4&D1=0&D2=0&D3=0&D4=10&D5=Date>4</a>&nbsp;<a href=themes.php?PGN=5&D1=0&D2=0&D3=0&D4=10&D5=Date>5</a>&nbsp; (75)&nbsp; <b><a href=themes.php?PGN=2&D1=0&D2=0&D3=0&D4=10&D5=Date>&gt;&gt;</a></b></p><br></td>
 </tr>
</table>

      </td>
    </tr>
</table>
 <center>
  <table border="0" width="851" cellspacing="0" cellpadding="0" bgcolor="#F5FFF2">
  </center>

    <tr>
      <td width="100%" background="../images/4theme-bottom-3.gif"><img border="0" src="../images/4theme-bottom-1.gif"></td>
    </tr>
    <tr>
      <td width="100%" background="../images/4theme-bottom-3.gif">
          <center>
          <table border="0" width="100%" align="left">
            <tr>
              <td width="15%" valign="top" align="right"></td>
              <td width="15%" valign="top" align="center">

          </center>

              <a href="http://www.brodyaga.com/pages/adv/desktops/desktop12.php" target="_blank">

              <img border="0" src="../images/dc2.jpg" alt="Desktop Calendars" width="287" height="197">
              </a>
              </td>
          <center>
              <td width="49%" valign="top" align="right">
                <p align="center"><a href="http://www.brodyaga.com" target="_blank"><img border="0" src="../images/brod2.jpg" alt="Brodyaga.com"></a></td>
            </tr>
          </table>
          </center>
      </td>
    </tr>
    <tr>
      <td width="100%" background="../images/4theme-bottom-3.gif"><img border="0" src="../images/4theme-bottom-2.gif"></td>
    </tr>
  </table>

<p class="textcr" align="center">� Copyright 1997-2020.
        Lighttek Software. All rights reserved</p>

<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-1496420-1";
urchinTracker();
</script>


</body>

</html>